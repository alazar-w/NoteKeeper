package com.example.hinote;

import static org.junit.Assert.*;

public class NextThroughNotesTest {

}